package com.proyecto.interfaces;

public interface IUsuariosC
{
    public boolean alta(String user, String pass);
	public boolean buscar (String user);
}