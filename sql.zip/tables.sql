DROP DATABASE PROYECTO;
CREATE DATABASE PROYECTO;
USE PROYECTO;

CREATE TABLE IF NOT EXISTS usuario 
	(id_usuario varchar(9) NOT NULL, 
	nick varchar(25) NOT NULL, 
	password varchar(25) NOT NULL, 
	rol_alumno boolean,
	primary key(id_usuario));

CREATE TABLE IF NOT EXISTS alumno 
	(id_alumno varchar(9) NOT NULL, 
	nombre varchar(30) NOT NULL,
	apellido1 varchar (20) NOT NULL,
	apellido2 varchar (20) NOT NULL,
	f_nac date,
	direccion varchar(200) NOT NULL,
	localidad varchar(50) NOT NULL,
	cp int(5) NOT NULL,
	provincia varchar(20) NOT NULL,
	telefono int(9),
	email varchar(100) NOT NULL,
	email2 varchar(100),
	disponibilidad boolean NOT NULL,
	observaciones varchar(300),
	primary key (id_alumno), 
	constraint clave_de_alumno foreign key (id_alumno) 
	references usuario(id_usuario)
	on delete cascade
	on update cascade);

CREATE TABLE IF NOT EXISTS ciclo 
	(id_ciclo int NOT NULL AUTO_INCREMENT, 
	nombre_ciclo varchar(49) NOT NULL, 
	siglas varchar(4) NOT NULL, 
	primary key(id_ciclo));

CREATE TABLE IF NOT EXISTS aptitud 
	(id_aptitud int NOT NULL AUTO_INCREMENT, 
	nombre_aptitud varchar(45) NOT NULL,
	nivel int(1) NOT NULL,
	descripcion varchar (150),
	PRIMARY KEY (id_aptitud));

CREATE TABLE IF NOT EXISTS cursa_ciclo 
	(id_alumno varchar(9) NOT NULL, 
	id_ciclo int NOT NULL,
	fecha_fin date,

	primary key (id_alumno, id_ciclo), 
	constraint fk_cursa_ciclo_alumno foreign key (id_alumno) 
	references alumno(id_alumno)
	on delete cascade
	on update cascade,
	constraint fk_cursa_ciclo_ciclo foreign key (id_ciclo) 
	references ciclo(id_ciclo) on delete cascade on update cascade);

CREATE TABLE IF NOT EXISTS centro 
	(id_centro int NOT NULL AUTO_INCREMENT, 
	nombre_centro varchar(100) NOT NULL, 
	PRIMARY KEY (id_centro));

CREATE TABLE IF NOT EXISTS OT 
	(id_OT int NOT NULL AUTO_INCREMENT,
	nombre_OT varchar(100) NOT NULL,
	descripcion_OT varchar(100) NOT NULL,
	id_centro int NOT NULL,
	primary key (id_OT),
	constraint fk_OT_centro foreign key (id_centro) 
	references centro(id_centro));

CREATE TABLE IF NOT EXISTS RRSS
	(id_rrss int NOT NULL AUTO_INCREMENT, 
	link varchar(200) NOT NULL, 
	id_alumno varchar(9),

	PRIMARY KEY (id_rrss),
	constraint fk_redes_sociales foreign key (id_alumno) 
	references alumno(id_alumno)
	on delete cascade
	on update cascade);

CREATE TABLE IF NOT EXISTS adquiere 
	(id_alumno varchar(9) NOT NULL, 
	id_aptitud int NOT NULL,

	primary key (id_alumno, id_aptitud),
	constraint fk_adquiere_alumno foreign key (id_alumno) 
	references alumno(id_alumno)
	on delete cascade
	on update cascade,
	constraint fk_adquiere_aptitud foreign key (id_aptitud) 
	references aptitud(id_aptitud));

CREATE TABLE IF NOT EXISTS cursa_OT 
	(id_OT int NOT NULL,
	id_alumno varchar(9) NOT NULL,
	fecha_fin date,
	constraint pk_cursa_OT primary key (id_OT, id_alumno),
	constraint fk_cursa_OT_alumno foreign key (id_alumno) references alumno(id_alumno),
	constraint fk_cursa_OT_OT foreign key (id_OT) references OT(id_OT));

