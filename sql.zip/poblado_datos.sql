insert into usuario values ("00000000A", "Root", "PSSWD", false);
insert into usuario values ("00000001A", "Dummie_Boy", "11111", true);
insert into usuario values ("00000002A", "Dummie_Boy2", "11111", true);
insert into usuario values ("00000003A", "Dummie_Boy3", "11111", true);
insert into usuario values ("00000004A", "Dummie_Girl", "22222", true);
insert into usuario values ("00000005A", "Dummie_Girl1", "22222", true);
insert into usuario values ("00000006A", "Dummie_Girl2", "22222", true);

insert into alumno values ("00000001A", "Frank", "Rojas", "Cabrillán","1988-02-22", "Calle Lejano Oriente 11, 1ª", "Sevilla", 41023, "Sevilla",954332214, "Frak_el_rojo@gmail.com","",true,"");
insert into alumno values ("00000002A", "Pedro", "Pedrola", "Segurola", "1922-12-12", "Calle Negra 12, 2ª", "Sevilla", 41009, "Sevilla",954332214, "Pedrola_rules@popopo.com","",true,"Nah");

insert into ciclo(nombre_ciclo, siglas) values ("Asistencia a Personas en Situación de Dependencia", "APSD");
insert into ciclo(nombre_ciclo, siglas) values ("Animación Sociocultural y Turismo", "ASCT");
insert into ciclo(nombre_ciclo, siglas) values ("Administración de Sistemas Informáticos en Red", "ASIR");
insert into ciclo(nombre_ciclo, siglas) values ("Desarrollo de aplicaciones web", "DAW");
insert into ciclo(nombre_ciclo, siglas) values ("Electromecánica de Vehículos Automóviles", "EVA");
insert into ciclo(nombre_ciclo, siglas) values ("Gestión Administrativa", "GA");
insert into ciclo(nombre_ciclo, siglas) values ("Instalaciones Eléctricas y Automáticas", "IEA");
insert into ciclo(nombre_ciclo, siglas) values ("Mediación Comunicativa", "MCO");
insert into ciclo(nombre_ciclo, siglas) values ("Sistemas Microinformáticos y redes", "SMR");
insert into ciclo(nombre_ciclo, siglas) values ("Sistemas de Telecomunicación Informáticos", "STI");

